# NovaTech-uz v4.9 — Render sinov paketi

1. GitHub'da PRIVATE repository yarating va ushbu papka ichidagi fayllarni repo ildiziga yuklang.
2. Render dashboard → New → Web Service → GitHub repongizni ulang.
3. Runtime: Python. Build Command: `pip install -r requirements.txt`. Start Command: `python server.py`.
4. Environment bo'limiga `NOVATECH_ADMIN_USER` va `NOVATECH_ADMIN_PASSWORD` kiriting. Maxfiy qiymatlarni hech kimga yubormang.
5. Deploy tugagach Render bergan `https://...onrender.com` havolani oching. `/api/health` holati `{"status":"ok"}` bo'lishi kerak.

MUHIM: Bu faqat vaqtinchalik sinov! Render bepul servisidagi lokal SQLite ma'lumotlari restart/redeploy paytida yo'qolishi mumkin. Haqiqiy mahsulotlar, mijozlar va moliyaviy ma'lumotlarni saqlamang. Admin loginida rate limiting va boshqa production himoyalar hali yo'q. Real ishga tushirishdan oldin doimiy DB, zaxira, xavfsizlik tekshiruvlari zarur.

Telegram @KalarovKH: mijoz xabarni qo'lda yuboradi; avtomatik jo'natish emas.
